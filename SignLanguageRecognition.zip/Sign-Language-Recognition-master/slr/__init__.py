from .main import main

__version__ = "1.0.0"
